package com.example.protogonus;

public class Dialog {
}
